%Name: Francis Mutetwa
%Student No: MTTFRA005
%Date: 29/02/2024
%Q2.2


function sort_experiment
%tic;
% Generate a 100x100 matrix of random floats in the range (0,1)

X = rand(5000);

tic;
% Sort each column of the matrix from minimum to maximum
for col = 1:size(X, 2)
    % Bubble sort algorithm for sorting the column
    for i = 1:size(X, 1)-1
        for j = 1:size(X, 1)-i
            % Compare adjacent elements and swap if necessary
            if X(j, col) > X(j+1, col)
                temp = X(j, col);
                X(j, col) = X(j+1, col);
                X(j+1, col) = temp;
            end
        end
    end
end
elapsed_time1 = toc;
% Display the sorted matrix
disp('Sorted Matrix:');
disp(X);



%Q2.2b: Matlab's built in sort function in Matlab:
tic;
% Generate a 100x100 matrix of random floats in the range (0,1)
%X = rand(100);

% Sort each column of the matrix from minimum to maximum
for col = 1:size(X, 2)
    X(:, col) = sort(X(:, col));
end
elapsed_time2 = toc;
% Display the sorted matrix
disp('Sorted Matrix:');
disp(X);



%Q2.2c: Parallelized sort function
tic;
% Preallocate a cell array to store sorted columns
sortedColumns = cell(1, size(X, 2));

% Parallelize sorting of columns using parfor
parfor col = 1:size(X, 2)
    sortedColumns{col} = sort(X(:, col));
end

% Concatenate sorted columns to form the sorted matrix
sortedMatrix = cell2mat(sortedColumns);
elapsed_time3 = toc;
% Display the sorted matrix
disp('Sorted Matrix:');
disp(sortedMatrix);


disp(['Elapsed time: ' num2str(elapsed_time1) '' ...
    ' seconds for the bubble sort algorithm to run'])
disp(['Elapsed time: ' num2str(elapsed_time2) ' seconds for Matlabs built ' ...
    'in sort function to run'])
disp(['Elapsed time: ' num2str(elapsed_time3) ' seconds for the' ...
    ' parallelized sort function to run'])

end 