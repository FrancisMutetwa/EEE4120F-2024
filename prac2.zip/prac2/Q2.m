%Author: FRANCIS MUTETWA
%Studen No: MTTFRA005
%Date created: 29/02/2024

tic;
% Generate a 100x100 matrix of integers with values between 1 and 10
X = randi([1, 10], 100);
% Initialize a variable to store the count of 1s
totalOnes = 0;
% Parallelize counting the number of 1s in the matrix using parfor
parfor i = 1:numel(X)
    if X(i) == 1
        % Increment count of 1s
        localCount = 1;
    else
        localCount = 0;
    end
    % Sum local counts
    localCounts(i) = localCount;
end
% Sum up local counts
totalOnes = sum(localCounts);
elapsed_time = toc;
% Display the total count of 1s
disp(['Total number of 1s in the matrix: ', num2str(totalOnes)]);
disp(['Elapsed time: ' num2str(elapsed_time) ' seconds to run']);
